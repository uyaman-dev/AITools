from .xinference import Xinference
